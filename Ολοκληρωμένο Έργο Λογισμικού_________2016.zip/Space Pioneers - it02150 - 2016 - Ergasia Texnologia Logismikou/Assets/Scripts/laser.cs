﻿using UnityEngine;
using System.Collections;

public class laser : MonoBehaviour {

	[Tooltip("The movement speed of the laser")]
	public float moveSpeed = 3;

	[Tooltip("The sound that plays when lazer is fired")]
	public AudioClip soundLazer;
	public AudioClip soundExplosion;
	internal GameObject soundSource;
	internal GameObject soundSource2;

	// variable for referencing the transform this script is attached to
	internal Transform thisTransform;

	// Use this for initialization
	void Start () {
		
		// referencing the transform this script is attached to
		thisTransform = transform;

		// referencing the gameobject this script is attached to
		soundSource = gameObject;
		soundSource2 = gameObject.transform.GetChild (0).gameObject;

		if ( soundLazer )    
		{
			soundSource.GetComponent<AudioSource>().PlayOneShot(soundLazer);
		}
	}
	
	// Update is called once per frame
	void Update () {

		//move laser up
		thisTransform.position += Vector3.up * moveSpeed * Time.deltaTime;

		//destroy after exits screen
		if (thisTransform.position.y > Camera.main.transform.position.y + Camera.main.orthographicSize + 1) {
			Destroy (gameObject);
		}
	}

	//called by the SpaceAlien that collides with the laser
	public void LaserDie () {
		if ( soundExplosion )    
		{
			soundSource2.GetComponent<AudioSource>().PlayOneShot(soundExplosion);
		}
		soundSource2.GetComponent<SpriteRenderer> ().enabled = false;
	}
}
