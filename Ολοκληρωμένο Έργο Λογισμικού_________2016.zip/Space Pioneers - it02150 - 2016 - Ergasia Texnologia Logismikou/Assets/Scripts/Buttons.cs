﻿using UnityEngine;
using System.Collections;
using UnityEngine.UI;
using UnityEngine.SceneManagement;

public class Buttons : MonoBehaviour {

	public void LoadMenu () {
		SceneManager.LoadScene("Menu");
	}

	public void LoadGame () {
		SceneManager.LoadScene("Game");
	}

	public void ExitGame () {
		Application.Quit ();
	}
}
