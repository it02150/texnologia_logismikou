﻿using UnityEngine;
using System.Collections;
using UnityEngine.UI;

public class ButtonCredits : MonoBehaviour {

	GameObject creditsinfo;

	// Use this for initialization
	void Start () {
		creditsinfo = GameObject.Find ("CreditsInfoButton");
		creditsinfo.SetActive(false);
	}
	
	public void showHide (){
		
		if (creditsinfo.activeInHierarchy) {
			creditsinfo.SetActive(false);
		}else {
			creditsinfo.SetActive(true);
		}
			
	}
}
