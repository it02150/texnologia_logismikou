﻿using UnityEngine;
using System.Collections;
using UnityEngine.UI;

public class ButtonSound : MonoBehaviour {

	Image colorLight;

	// Use this for initialization
	void Start () {
		
		//reference and initialize sound-image color
		colorLight = GameObject.Find ("SoundOnOffImage").GetComponent<Image> ();
		colorLight.color = Color.green;
	}
	
	public void SoundOnOffColor () {
		
		if (colorLight.color == Color.green) {
			colorLight.color = Color.red;
		} else {
			colorLight.color = Color.green;
		}
	}
}
