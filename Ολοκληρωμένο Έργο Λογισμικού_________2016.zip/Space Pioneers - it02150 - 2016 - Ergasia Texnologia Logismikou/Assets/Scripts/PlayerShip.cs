﻿using UnityEngine;
using System.Collections;

public class PlayerShip : MonoBehaviour {

	// The target position the player will move towards
	internal Vector3 targetPosition;
	// variable for referencing the transform this script is attached to
	internal Transform thisTransform;

	[Tooltip("The movement speed of the PlayerShip")]
	public float moveSpeed = 3;


	// Use this for initialization
	void Start () {
		
		// referencing the transform this script is attached to
		thisTransform = transform;
		targetPosition = thisTransform.transform.position;
	}
	
	// Update is called once per frame
	void Update () {
		
		if (Input.GetMouseButtonDown (0)) {
			targetPosition = Camera.main.ScreenToWorldPoint(Input.mousePosition);
			targetPosition.z = thisTransform.transform.position.z;
		}
			
		// Move the player towards the target position
		thisTransform.position = Vector3.MoveTowards( thisTransform.position, targetPosition, moveSpeed * Time.deltaTime);
	}

	//called by the SpaceAlien that collides with the PlayerShip
	public void PlayerShipDie () {
		Destroy (gameObject);
	}
}
