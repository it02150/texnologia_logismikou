﻿using UnityEngine;
using System.Collections;

public class AutoShoot : MonoBehaviour {

	public Transform laserPrefab;

	[Tooltip("The Auto-shooting speed in shots per second")]
	public float shootSpeed = 2;
	internal float lastShotTime;

	// Use this for initialization
	void Start () {
		lastShotTime = Time.time;
	}

	//called by the SpaceAlien that collides with the AutoShoot collider
	public void Shootlaser () {
		if (Time.time - lastShotTime > 1 / shootSpeed) {
			Transform newLaser;
			newLaser = Instantiate (laserPrefab) as Transform;
			newLaser.transform.position = transform.position;
			lastShotTime = Time.time;
		}
	}
}
