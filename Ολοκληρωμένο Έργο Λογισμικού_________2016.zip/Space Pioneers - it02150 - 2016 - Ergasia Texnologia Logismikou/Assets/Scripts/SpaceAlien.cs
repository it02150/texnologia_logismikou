﻿using UnityEngine;
using System.Collections;

public class SpaceAlien : MonoBehaviour {

	[Tooltip("The movement speed of the SpaceAlien")]
	public float moveSpeed = 2;

	// variable for referencing the transform this script is attached to
	internal Transform thisTransform;

	[Tooltip("The sound that plays when alien explodes")]
	public AudioClip soundExplosion;
	internal GameObject soundSource;

	// Use this for initialization
	void Start () {

		// referencing the transform this script is attached to
		thisTransform = transform;

		// referencing the gameobject this script is attached to
		soundSource = gameObject;


	}
	
	// Update is called once per frame
	void Update () {

		//move SpaceAlien down
		thisTransform.position -= Vector3.up * moveSpeed * Time.deltaTime;

		//destroy after exits screen
		if (thisTransform.position.y < Camera.main.transform.position.y -Camera.main.orthographicSize  -2) {
			Destroy (gameObject);
		}
	}

	void OnTriggerEnter2D(Collider2D other) {
		if (other.tag == "laserObject") {
			other.SendMessage ("LaserDie");
			Destroy (gameObject);
		}
		else if (other.tag == "PlayerShipObject") {
			if ( soundExplosion )    
			{
				soundSource.GetComponent<AudioSource>().PlayOneShot(soundExplosion);
			}
			other.SendMessage ("PlayerShipDie");
		}
	}

	void OnTriggerStay2D(Collider2D other) {
		if (other.tag == "AutoShootObject" && transform.position.y < Camera.main.transform.position.y + Camera.main.orthographicSize + 0.5f) {
			other.SendMessage ("Shootlaser");
		}
	}
}
