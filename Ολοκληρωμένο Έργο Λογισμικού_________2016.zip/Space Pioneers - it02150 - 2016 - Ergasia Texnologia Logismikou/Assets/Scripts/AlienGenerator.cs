﻿using UnityEngine;
using System.Collections;

public class AlienGenerator : MonoBehaviour {

	public Transform alienPrefab;

	[Tooltip("The alien generation speed in shots per second")]
	public float genSpeed = 2;
	internal float lastGenTime;

	// Use this for initialization
	void Start () {
		lastGenTime = Time.time;
	}

	// Update is called once per frame
	void Update () {

		if (Time.time - lastGenTime > 1 / genSpeed) {
			Transform newLaser;
			newLaser = Instantiate (alienPrefab) as Transform;
			newLaser.transform.position = new Vector3 (Random.Range(-(Camera.main.aspect * Camera.main.orthographicSize -0.8f), Camera.main.aspect * Camera.main.orthographicSize -0.8f), transform.position.y, transform.position.z);
			lastGenTime = Time.time;
		}
	}
}
